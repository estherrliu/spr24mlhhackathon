/*
 * Numbers.cpp
 *
 *  Created on: Mar 23, 2024
 *      Author: aaron88
 */

#include <stdlib.h>
#include <time.h>
#include "../inc/ST7735.h"
#include <assert.h>
#include <numbers.hpp>
#include <ti/devices/msp/msp.h>
#include "../inc/Timer.h"

#define L1 1<<12
#define L2 1<<17
#define L3 1
#define L4 1<<16

#define interval 20000000

int enabled, currNum, x, y, ind, prev, counter, win;
unsigned long startTime;
const int spiral[137] = {6,6,5,6,6,6,4,6,5,5,6,6,4,5,4,4,4,4,5,4,4,4,4,4,4,3,4,4,4,3,4,4,2,3,3,2,3,2,2,2,2,2,1,2,2,2,0,2,1,2,0,1,1,0,0,0,0,0,0,7,0,7,7,7,6,7,7,6,6,6,6,5,6,5,6,5,5,4,4,4,4,3,4,4,3,4,4,3,3,2,2,2,1,2,1,1,0,0,1,0,0,0,0,7,6,6,7,6,6,6,5,5,4,4,4,2,4,2,4,3,3,2,2,2,3,2,2,3,2,2,2,2,3,2,2,2,2};
static int randint(int n) {
  if ((n - 1) == RAND_MAX) {
    return rand();
  } else {
    // Supporting larger values for n would requires an even more
    // elaborate implementation that combines multiple calls to rand()
    assert (n <= RAND_MAX);

    // Chop off all of the values that would cause skew...
    int end = RAND_MAX / n; // truncate skew
    assert (end > 0);
    end *= n;

    // ... and ignore results from rand() that fall above that limit.
    // (Worst case the loop condition should succeed 50% of the time,
    // so we can expect to bail out of this loop pretty quickly.)
    int r;
    while ((r = rand()) >= end);

    return r % n;
  }
}


static int read_SW() {
    return ((GPIOA->DIN31_0 & 0x0B000000)) >> 24 | ((GPIOA->DIN31_0 & 0x0008000) >> 13);
}



void numbers_init() {
    TimerG12_Init();
    enabled = 0, currNum = 0, x = 60, y = 0, ind = 0, prev = 0, counter = 0, win = 0;
    startTime = -10000000;
}

void numbers_start() {
    enabled = 1;
    currNum = randint(7)+1;
}

int numbers_update() {
    if (enabled == 1) {
        char outChar = currNum + 0x30;
        ST7735_DrawChar(x, y, outChar, 0xF800, 0x0000, 3);
        x += (spiral[ind] >= 1 && spiral[ind] <= 3) ? 4 : ((spiral[ind] >=5 && spiral[ind] <= 7) ? -4 : 0);
        y += (spiral[ind] == 7 || spiral[ind] == 0 || spiral[ind] == 1) ? -4 : ((spiral[ind] >=3 && spiral[ind] <= 5) ? 4: 0);
        ind+=3;
        if (ind > 136)
            enabled = 2;
    } else if (enabled == 2) {
        int curr = GPIOA->DIN31_0 & 1<<24;
        if (curr != prev) {
            if (curr) {
                counter++;
                GPIOB->DOUTSET31_0 = 1<<17;
                if (counter == currNum)
                    startTime = TIMG12->COUNTERREGS.CTR;
                if (counter > currNum) {
                    enabled = 3;
                    startTime = TIMG12->COUNTERREGS.CTR;
                    win = 1;
                }
            } else
                GPIOB->DOUTCLR31_0 = 1<<17;
            prev = curr;
        }
        if (startTime - TIMG12->COUNTERREGS.CTR > 100000000 && counter == currNum) {
            startTime = TIMG12->COUNTERREGS.CTR;
            enabled = 4;
            win = 1;
        }
    } else if (enabled == 3) {
        unsigned long currTime = TIMG12->COUNTERREGS.CTR;

        if (startTime - currTime > 3 * interval && win == 1) {
            GPIOB->DOUTSET31_0 = L1 | L4;
            win++;
        } else if (startTime - currTime > 4 * interval && win == 2) {
            GPIOB->DOUTCLR31_0 = L1 | L4;
            win++;
        } else if (startTime - currTime > 5 * interval && win == 3) {
            GPIOB->DOUTSET31_0 = L1 | L4;
            win++;
        } else if (startTime - currTime > 6 * interval && win == 4) {
            GPIOB->DOUTCLR31_0 = L1 | L4;
            win++;
            return -1;
        }
    } else if (enabled == 4) {
        unsigned long currTime = TIMG12->COUNTERREGS.CTR;

        if (startTime - currTime > 3 * interval && win == 1) {
            GPIOB->DOUTSET31_0 = L2 | L3;
            win++;
        } else if (startTime - currTime > 4 * interval && win == 2) {
            GPIOB->DOUTCLR31_0 = L2 | L3;
            win++;
        } else if (startTime - currTime > 5 * interval && win == 3) {
            GPIOB->DOUTSET31_0 = L2 | L3;
            win++;
        } else if (startTime - currTime > 6 * interval && win == 4) {
            GPIOB->DOUTCLR31_0 = L2 | L3;
            win++;
            return 1;
        }
    }
    return 0;

}
