/*
 * Numbers.h
 *
 *  Created on: Mar 23, 2024
 *      Author: aaron88
 */

#ifndef NUMBERS_HPP_
#define NUMBERS_HPP_

    void numbers_init();
    void numbers_start();
    int numbers_update();

#endif /* NUMBERS_HPP_ */
