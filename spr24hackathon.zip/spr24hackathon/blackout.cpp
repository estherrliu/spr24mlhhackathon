/*
 * blackout.cpp
 *
 *  Created on: Mar 23, 2024
 *      Author: aaron88
 */

#include <stdlib.h>
#include <time.h>
#include <assert.h>
#include <blackout.hpp>
#include <ti/devices/msp/msp.h>
#include "../inc/Timer.h"

#define L1 1<<12
#define L2 1<<17
#define L3 1
#define L4 1<<16

#define inputCM 0x00050081
#define outputCM 0x00000081

#define interval 20000000

static int win, prev;
static int toggleConfig[4] = {L2, L4, L3, L1};
static int state[4];
static unsigned long startTime;


static int randint(int n) {
  if ((n - 1) == RAND_MAX) {
    return rand();
  } else {
    // Supporting larger values for n would requires an even more
    // elaborate implementation that combines multiple calls to rand()
    assert (n <= RAND_MAX);

    // Chop off all of the values that would cause skew...
    int end = RAND_MAX / n; // truncate skew
    assert (end > 0);
    end *= n;

    // ... and ignore results from rand() that fall above that limit.
    // (Worst case the loop condition should succeed 50% of the time,
    // so we can expect to bail out of this loop pretty quickly.)
    int r;
    while ((r = rand()) >= end);

    return r % n;
  }
}

static void toggle_LED (int input) {
    GPIOB->DOUTTGL31_0 = input;
    int pins[] = {L1, L2, L3, L4};
    for (int i = 0; i < 4; i++) state[i] ^= input & pins[i];
}

static int read_SW() {
    return ((GPIOA->DIN31_0 & 0x0B000000)) >> 24 | ((GPIOA->DIN31_0 & 0x0008000) >> 13);
}

static int check_Win() {
    if (!(state[0] | state[1] | state[2] | state[3]))
        return 1;
    return 0;
}

void blackout_init() {
    srand(time(NULL));

    IOMUX->SECCFG.PINCM[28] = outputCM;
    IOMUX->SECCFG.PINCM[42] = outputCM;
    IOMUX->SECCFG.PINCM[11] = outputCM;
    IOMUX->SECCFG.PINCM[32] = outputCM;

    GPIOB->DOE31_0 |= L1 | L2 | L3 | L4;

    IOMUX->SECCFG.PINCM[53] = inputCM;
    IOMUX->SECCFG.PINCM[54] = inputCM;
    IOMUX->SECCFG.PINCM[36] = inputCM;
    IOMUX->SECCFG.PINCM[59] = inputCM;

    TimerG12_Init();
}

void blackout_start() {
    win = 0, prev = 0;
    toggleConfig[0] = L2; toggleConfig[1] = L4; toggleConfig[2] = L3; toggleConfig[3] = L1;
    GPIOB->DOUTSET31_0 = L1 | L2 | L3 | L4;
    int pins[] = {L1, L2, L3, L4};

    for (int j = 0; j < 4; j++) {
        int rand = randint(3);

        for (int i = 0; i < rand; i++) {
            int pin = pins[randint(4) % 4];

            while (toggleConfig[j] & pin)
                pin = pins[randint(4) % 4];

            toggleConfig[j] |= pin;
        }

        state[j] = pins[j];
    }
}

int blackout_update() {
    if (!win) {
        int curr = read_SW();

        if (curr != prev) {
            if (curr != 0) {
                curr = curr & (~(curr & prev));

                int i;
                for (i = 0; curr >> i > 0; i++);

                toggle_LED(toggleConfig[i-1]);

                win = check_Win();
                if (win) startTime = TIMG12->COUNTERREGS.CTR;
            }
            prev = curr;
        }
    } else {
        unsigned long currTime = TIMG12->COUNTERREGS.CTR;

        if (startTime - currTime > 3 * interval && win == 1) {
            GPIOB->DOUTSET31_0 = L1 | L2 | L3 | L4;
            win++;
        } else if (startTime - currTime > 4 * interval && win == 2) {
            GPIOB->DOUTCLR31_0 = L1 | L2 | L3 | L4;
            win++;
        } else if (startTime - currTime > 5 * interval && win == 3) {
            GPIOB->DOUTSET31_0 = L1 | L2 | L3 | L4;
            win++;
        } else if (startTime - currTime > 6 * interval && win == 4) {
            GPIOB->DOUTCLR31_0 = L1 | L2 | L3 | L4;
            win++;
        }
    }
    if (win == 5) return 1;
    return 0;
}


