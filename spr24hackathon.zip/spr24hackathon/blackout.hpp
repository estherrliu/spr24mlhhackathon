/*
 * blackout.h
 *
 *  Created on: Mar 23, 2024
 *      Author: aaron88
 */

#ifndef BLACKOUT_HPP_
#define BLACKOUT_HPP_

void blackout_init();
int blackout_update();
void blackout_start();



#endif /* BLACKOUT_HPP_ */
